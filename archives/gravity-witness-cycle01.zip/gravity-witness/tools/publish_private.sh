#!/usr/bin/env bash
# Explicit user-controlled publishing; NOT executed by this research cycle.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v gh >/dev/null || { echo 'Install GitHub CLI and authenticate first.' >&2; exit 1; }
login="$(gh api user --jq .login)"
[[ "$login" == "dhinchcliffe" ]] || { echo "Unexpected account: $login" >&2; exit 1; }
if gh repo view dhinchcliffe/gravity-witness --json name >/dev/null 2>&1; then
  echo 'Repository already exists. Inspect visibility and history before pushing.' >&2
  exit 1
fi
gh repo create dhinchcliffe/gravity-witness --private --source=. --remote=origin --push
[[ "$(gh repo view --json visibility --jq .visibility)" == "PRIVATE" ]]
