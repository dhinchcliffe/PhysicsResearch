#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p results figures
python -m pytest -q --junitxml=results/pytest.xml | tee results/pytest.txt
python run_dp.py | tee results/run_dp.log
python run_cycle01.py | tee results/run_cycle01.log
